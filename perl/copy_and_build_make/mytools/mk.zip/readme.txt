编译并执行:
gcc -o mk mk.c && ./mk
