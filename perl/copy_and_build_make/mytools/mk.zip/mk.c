#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

int main(int argc, char **argv)
{
    char *shellFileName = "mk.sh";
    char *shellPath = "/bin/bash";
    DIR *dir;
    struct dirent *ptr;
    int isFind = 0;


    dir = opendir("./");
    while((ptr = readdir(dir)) != NULL)
    {
        if (strcmp(ptr->d_name, shellFileName) == 0)
        {
            isFind = 1;
            break;
        }
    }
    closedir(dir);

    if (isFind)
    {
        char cmd[500] = "";
        char argvList[400] = "";

        memset(cmd, 0, sizeof(cmd));
        memset(argvList, 0, sizeof(argvList));
        if (argc > 1)
        {
            int i = 1;          // argv[0]是本程序名称, 忽略
            for (; i < argc; i++)
            {
                sprintf(argvList, "%s %s", argvList, argv[i]);
            }
        }
        sprintf(cmd, "%s %s %s", shellPath, shellFileName, argvList);
        printf("%s\n" , cmd);
        system(cmd);
    }
    else
    {
        printf("没找到文件: %s\n" , shellFileName);
    }

    exit(0);
}
